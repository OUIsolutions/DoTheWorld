#include "resource/extras.c"
#include "resource/loaders_and_unloaders.c"
#include "resource/setters.c"
#include "resource/constructors_and_destructors.c"
