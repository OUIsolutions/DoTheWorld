
struct DtwStringArray * dtw_list_dirs_recursively(const char *path,bool concat_path);


struct DtwStringArray *  dtw_list_files_recursively(const char *path,bool concat_path);


struct DtwStringArray * dtw_list_all_recursively(const char *path,bool concat_path);
