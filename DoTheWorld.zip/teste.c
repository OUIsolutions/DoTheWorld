#include <stdio.h>
#include <time.h>

int main() {

    
    return 0;
}