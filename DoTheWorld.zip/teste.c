#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main() {

    char *r = malloc(20);

    return 0;
}