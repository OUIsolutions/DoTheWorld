
#include "doTheWorld/doTheWorldMain.h"

int main(int argc, char *argv[]){
 
  dtw_create_dir_recursively("a/b/c");

  return 0;
}