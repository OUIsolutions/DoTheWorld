#include "doTheWorld.h"

int main(int argc, char *argv[]){
 
  dtw_create_dir_recursively("tests/target/sub_folder/a/b/c");

  return 0;
}