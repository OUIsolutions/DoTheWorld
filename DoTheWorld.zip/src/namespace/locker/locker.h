

typedef struct DtwLockerModule{
    DtwLocker * (*newLocker)();
    int (*lock)( DtwLocker *self, const  char *element);
    void (*unlock)( DtwLocker *self, const  char *element);
    void (*represemt)( DtwLocker *self);
    void (*free)( DtwLocker *self);

}DtwLockerModule;

DtwLockerModule newDtwLockerModule();