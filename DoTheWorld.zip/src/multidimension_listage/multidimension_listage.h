
 DtwStringArray * dtw_list_dirs_recursively(const char *path,bool concat_path);


 DtwStringArray *  dtw_list_files_recursively(const char *path,bool concat_path);


 DtwStringArray * dtw_list_all_recursively(const char *path,bool concat_path);
